/*
  CHANGE the default macros FIRST!!!
*/

#ifndef CONFIG_H
#define CONFIG_H

#define HIDE_FILE       "klog"  /* we will hide the file name began with the HIDE_FILE string. */
#define HIDE_TASK	""

#define TMPSZ		150

#endif



