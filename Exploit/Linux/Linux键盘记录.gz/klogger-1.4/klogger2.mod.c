#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

#undef unix
struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = __stringify(KBUILD_MODNAME),
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0x65b4e613, "struct_module" },
	{ 0x7da8156e, "__kmalloc" },
	{ 0x6c3397fb, "malloc_sizes" },
	{ 0x2240b497, "boot_cpu_data" },
	{ 0x20000329, "simple_strtoul" },
	{ 0x7a2c6a6d, "filp_close" },
	{ 0x51913ed8, "kobject_unregister" },
	{ 0x1d26aa98, "sprintf" },
	{ 0xd7474566, "__copy_to_user_ll" },
	{ 0x1af40e18, "__copy_from_user_ll" },
	{ 0x1b7d4074, "printk" },
	{ 0x1075bf0, "panic" },
	{ 0x1e6d26a8, "strstr" },
	{ 0x436006da, "call_usermodehelper" },
	{ 0x9db52248, "fput" },
	{ 0x123d3b6a, "kmem_cache_alloc" },
	{ 0x72270e35, "do_gettimeofday" },
	{ 0x37a0cba, "kfree" },
	{ 0x8b63761d, "fget" },
	{ 0x25da070, "snprintf" },
	{ 0x8235805b, "memmove" },
	{ 0x4d48c8e5, "filp_open" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";

